﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DateCalculator.Models;

namespace DateCalculator.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public HomeController()
        {
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        /// <summary>
        /// Days Calculation between fromdate to todate
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult DaysCalculation(string fromDate, string toDate)
        {
            var fromdateyear = Convert.ToInt32(fromDate.Split('/')[2]);
            var todateyear = Convert.ToInt32(toDate.Split('/')[2]);
            var yearcount = todateyear - fromdateyear;
            var finaldays = 0;

            if (yearcount == 0)
            {
                var fromdateday = Convert.ToInt32(fromDate.Split('/')[0]);
                var fromdatemonth = fromDate.Split('/')[1];

                var todateday = Convert.ToInt32(toDate.Split('/')[0]);
                var todatemonth = toDate.Split('/')[1];

                finaldays = GetDays(fromdatemonth, todatemonth, fromdateday, todateday, finaldays);
            }

            if (yearcount > 0)
            {
                fromdateyear = Convert.ToInt32(fromDate.Split('/')[2]);
                todateyear = Convert.ToInt32(toDate.Split('/')[2]);
                var firstyear = fromdateyear;
                int[] years = new int[20];
                var i = 0;

                while (Convert.ToInt32(fromdateyear) <= Convert.ToInt32(todateyear))
                {
                    years[i] = fromdateyear++;
                    i++;
                }

                for (i = 0; i < years.Length; i++)
                {
                    if (years[i] != 0)
                    {
                        var fromdateday = Convert.ToInt32(fromDate.Split('/')[0]);
                        var fromdatemonth = fromDate.Split('/')[1];

                        var todateday = Convert.ToInt32(toDate.Split('/')[0]);
                        var todatemonth = toDate.Split('/')[1];

                        if (years[i] == firstyear)
                        {
                            todatemonth = "12";
                            todateday = 31;
                            finaldays = finaldays + GetDays(fromdatemonth, todatemonth, fromdateday, todateday, finaldays);
                        }

                        else if (years[i] == todateyear)
                        {
                            fromdatemonth = "01";
                            fromdateday = 1;
                            finaldays = finaldays + GetDays(fromdatemonth, todatemonth, fromdateday, todateday, finaldays);
                        }

                        else
                        {
                            finaldays = finaldays + 365;
                        }
                    }
                }
            }

            return new JsonResult(finaldays);
        }

        private int GetDays(string fromdatemonth, string todatemonth, int fromdateday, int todateday, int finaldays)
        {
            finaldays = 0;
            var frommonth = Convert.ToInt32(fromdatemonth);
            var tomonth = Convert.ToInt32(todatemonth);
            var firstmonth = (fromdatemonth == "1" || fromdatemonth == "2" || fromdatemonth == "3" ||
                fromdatemonth == "4" || fromdatemonth == "5" || fromdatemonth == "6" ||
                fromdatemonth == "7" || fromdatemonth == "8" || fromdatemonth == "9") ? "0" + fromdatemonth : fromdatemonth;

            var lastmonth = (todatemonth == "1" || todatemonth == "2" || todatemonth == "3" ||
                todatemonth == "4" || todatemonth == "5" || todatemonth == "6" ||
                todatemonth == "7" || todatemonth == "8" || todatemonth == "9") ? "0" + todatemonth : todatemonth;

            List<MonthList> monthlist = GetMonthsList();

            int[] months = new int[12];
            var i = 0;
            while (Convert.ToInt32(frommonth) <= Convert.ToInt32(tomonth))
            {
                months[i] = frommonth++;
                i++;
            }

            for (var j = 0; j < monthlist.Count(); j++)
            {
                if (monthlist[j].Month == firstmonth)
                {
                    finaldays = finaldays + monthlist[j].Monthdays - (fromdateday - 1);
                }

                else if (monthlist[j].Month == lastmonth)
                {
                    var days = monthlist[j].Monthdays - (todateday);
                    finaldays = finaldays + (monthlist[j].Monthdays - days);
                }
                else
                {
                    for (i = 0; i < months.Length; i++)
                    {
                        var month = (months[i] == 1 || months[i] == 2 || months[i] == 3 ||
                            months[i] == 4 || months[i] == 5 || months[i] == 6 ||
                            months[i] == 7 || months[i] == 8 || months[i] == 9) ? "0" + months[i] : months[i].ToString();
                        if (monthlist[j].Month == month)
                        {
                            finaldays = finaldays + monthlist[j].Monthdays;
                        }
                    }
                }
            }

            return finaldays;
        }
        public List<MonthList> GetMonthsList()
        {
            List<MonthList> _monthList = new List<MonthList>();
            _monthList.Add(new MonthList { Month = "01", Monthdays = 31 });
            _monthList.Add(new MonthList { Month = "02", Monthdays = 28 });
            _monthList.Add(new MonthList { Month = "03", Monthdays = 31 });
            _monthList.Add(new MonthList { Month = "04", Monthdays = 30 });
            _monthList.Add(new MonthList { Month = "05", Monthdays = 31 });
            _monthList.Add(new MonthList { Month = "06", Monthdays = 30 });
            _monthList.Add(new MonthList { Month = "07", Monthdays = 31 });
            _monthList.Add(new MonthList { Month = "08", Monthdays = 31 });
            _monthList.Add(new MonthList { Month = "09", Monthdays = 30 });
            _monthList.Add(new MonthList { Month = "10", Monthdays = 31 });
            _monthList.Add(new MonthList { Month = "11", Monthdays = 30 });
            _monthList.Add(new MonthList { Month = "12", Monthdays = 31 });

            return _monthList;
        }

        public class MonthList
        {
            public string Month { get; set; }
            public int Monthdays { get; set; }
        }
    }
}
