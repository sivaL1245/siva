﻿
(function (angular) {
    'use strict';

    angular.module('DateApp').controller('DateValidatorController', DateValidatorController);

    DateValidatorController.$inject = ["$scope"];

    function DateValidatorController($scope) {

        // Default days count initialization
        $scope.totalDays = 0;

        $scope.monthlist = [{ month: '01', monthdays: 31 }, { month: '02', monthdays: 28 }, { month: '03', monthdays: 31 }, { month: '04', monthdays: 30 },
        { month: '05', monthdays: 31 }, { month: '06', monthdays: 30 }, { month: '07', monthdays: 31 }, { month: '08', monthdays: 31 },
        { month: '09', monthdays: 30 }, { month: '10', monthdays: 31 }, { month: '11', monthdays: 30 }, { month: '12', monthdays: 31 }];

        // button click event of Calculate days
        $scope.Calculate = function () {
            var isValid = true;
            var dateformat = /^([1-9]{1}|0[1-9]{1}|1[0-9]{1}|2[0-9]{1}|3[0-1]{1})[/]([1-9]{1}|0[1-9]{1}|1[0-2]{1})[/][0-9]{2,4}$/;

            if (!$scope.Fromdate.match(dateformat)) {
                alert('Please provide valid from date.');
                isValid = false;
            }

            if (!$scope.Todate.match(dateformat)) {
                alert('Please provide valid to date.');
                isValid = false;
            }

            if (isValid) {

                // Caluclating Days from Server Side
                $.ajax({
                    url: '../Home/DaysCalculation',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        fromDate: $scope.Fromdate,
                        toDate: $scope.Todate,
                    },
                    success: function (response) {
                        alert("Total Days:" + response);

                    },
                    error: function (err) {
                        alert("Error occurred while calculating days.");
                    }
                });

                // Calculating Days from Client Side
                var fromdateyear = $scope.Fromdate.split('/')[2];
                var todateyear = $scope.Todate.split('/')[2];
                var yearcount = todateyear - fromdateyear;
                var finaldays = 0;

                if (yearcount == 0) {
                    var fromdateday = $scope.Fromdate.split('/')[0];
                    var fromdatemonth = $scope.Fromdate.split('/')[1];

                    var todateday = $scope.Todate.split('/')[0];
                    var todatemonth = $scope.Todate.split('/')[1];

                    finaldays = GetDays(fromdatemonth, todatemonth, fromdateday, todateday, finaldays);
                }

                if (yearcount > 0) {
                    var fromdateyear = $scope.Fromdate.split('/')[2];
                    var todateyear = $scope.Todate.split('/')[2];
                    var firstyear = fromdateyear;
                    var years = [];
                    var i = 0;

                    while (fromdateyear <= todateyear) {
                        year[i++] = fromdateyear++;
                    }

                    for (var i = 0; i < years.length; i++) {
                        var fromdateday = $scope.Fromdate.split('/')[0];
                        var fromdatemonth = $scope.Fromdate.split('/')[1];

                        var todateday = $scope.Todate.split('/')[0];
                        var todatemonth = $scope.Todate.split('/')[1];

                        if (years[i] == firstyear) {
                            todatemonth = '12';
                            todateday = 31;
                            finaldays = finaldays + GetDays(fromdatemonth, todatemonth, fromdateday, todateday, finaldays);
                        }

                        else if (years[i] == todateyear) {
                            fromdatemonth = '01';
                            fromdateday = 1;
                            finaldays = finaldays + GetDays(fromdatemonth, todatemonth, fromdateday, todateday, finaldays);
                        }

                        else {
                            finaldays = finaldays + 365;
                        }
                    }
                }
                $scope.totalDays = finaldays;
            }
        };

        function GetDays(fromdatemonth, todatemonth, fromdateday, todateday, finaldays) {

            finaldays = 0;
            var frommonth = fromdatemonth;
            var tomonth = todatemonth;
            var firstmonth = (fromdatemonth == '1' || fromdatemonth == '2' || fromdatemonth == '3' ||
                fromdatemonth == '4' || fromdatemonth == '5' || fromdatemonth == '6' ||
                fromdatemonth == '7' || fromdatemonth == '8' || fromdatemonth == '9') ? '0' + fromdatemonth : fromdatemonth;

            var lastmonth = (todatemonth == '1' || todatemonth == '2' || todatemonth == '3' ||
                todatemonth == '4' || todatemonth == '5' || todatemonth == '6' ||
                todatemonth == '7' || todatemonth == '8' || todatemonth == '9') ? '0' + todatemonth : todatemonth;

            var months = [];
            var i = 0;
            while (frommonth <= tomonth) {
                months[i++] = frommonth++;
            }

            for (var j = 0; j < $scope.monthlist.length; j++) {
                if ($scope.monthlist[j].month == firstmonth) {
                    finaldays = finaldays + $scope.monthlist[j].monthdays - (fromdateday - 1)
                }

                else if ($scope.monthlist[j].month == lastmonth) {
                    var days = $scope.monthlist[j].monthdays - (todateday);
                    finaldays = finaldays + ($scope.monthlist[j].monthdays - days);
                }
                else {
                    for (var i = 0; i < months.length; i++) {
                        var month = (months[i] == '1' || months[i] == '2' || months[i] == '3' ||
                            months[i] == '4' || months[i] == '5' || months[i] == '6' ||
                            months[i] == '7' || months[i] == '8' || months[i] == '9') ? '0' + months[i] : months[i];
                        if ($scope.monthlist[j].month == month) {
                            finaldays = finaldays + $scope.monthlist[j].monthdays;
                        }
                    }
                }
            }

            return finaldays;
        }

    }

}(window.angular));