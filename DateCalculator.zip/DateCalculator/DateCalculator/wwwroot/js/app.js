﻿var app = angular.module('DateApp', ['ngRoute']);
