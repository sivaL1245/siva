using Microsoft.VisualStudio.TestTools.UnitTesting;
using Xunit.Sdk;
using DateCalculator.Controllers;

namespace UnitTestProject
{
    [TestClass]
    public class DateCalculator
    {
        [TestMethod]
        public void DateCalculation()
        {
            HomeController _homeController = new HomeController();

          var result=  _homeController.DaysCalculation("01/01/2019", "31/12/2019");
            Assert.IsTrue(result != null);
        }
    }
}
